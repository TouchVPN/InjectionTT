package com.jsql.view.swing.sql.text;

public interface JTextPaneObjectMethod {
    
    default void switchSetterToVendor() {
        // Apply text
    }
}