package com.jsql.view.swing.manager.util;

public enum StateButton {
    
    STARTABLE,
    STOPPING,
    STOPPABLE
}