package com.jsql.view.swing.tab.dnd;

public class DnDTabData {
    
    public final DnDTabbedPane tabbedPane;
    
    protected DnDTabData(DnDTabbedPane tabbedPane) {
        this.tabbedPane = tabbedPane;
    }
}